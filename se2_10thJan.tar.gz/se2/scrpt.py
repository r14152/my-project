import subprocess,os
from subprocess import PIPE
fst = subprocess.Popen(["python","continue.py"])
fst.wait()
fst.poll()
#subprocess.PIPE.read()
#fst.wait()
dsp = subprocess.Popen(["python","another.py"])
dsp.wait()
#dsp.communicate()
#print stdout[0]
