$(document).ready(function () {
    
    var inpKeyCode  = [0, 13, 38, 40];
    var slctKeyCode = [0, 13, 45, 46, 37, 39];
    var slctSprCode = [32, 27, 37];
    var addRmvClsCode = [true, false];
    var addRmvClsFunc = [removeClass, addClass];
    var slctSprFuncCaller = [doNothing, addRemoveClass, discardSubtype, saveSubtypeDag];
    var slctFunctCaller = [doNothing, doNothing, addType, editType, deleteType, subtypeSelection];
    var functionCaller = [doNothing, doNothing, addCondition, focusTypes, focusTypes];
    var errorMsgCaller = [regexCheck, errorExists];
    var slctFocusSession = [regexCheck, doNothing];
    var nullArray      = [null];
    var editingType    = false;
    var editingTypeArr = [false, null, true];
    var addElementCall = [addElement, incorrectValue, editOldType, incorrectValue];
    var dagEntryFun2   = [doNothing, doNothing, updateDag];
    var dagEntryFun1   = [doNothing, doNothing, deleteAtPos];
    var dagEntryFun    = [doNothing, doNothing, modifyDagEntry];
    
    var dag = new Object();
    dag.types = [];
    //Define some Vars
    var headersDiv = $('#header #container');
    var typeCounts = 0;
    var contentDiv = $('#midPage #Content');
    var divSubCont = $('#midPage #subContent');
    //Create input Text Box.
    headersDiv.append("<label id='lblInpBox' class='lblGeneral'>Add/Edit Type:</label><br>");
    var inpTextBox = $(document.createElement("input"));
    inpTextBox.attr("id", "txtInpBox");
    inpTextBox.attr("placeholder", "Add/Edit Type");
    headersDiv.attr("class", "center");
    headersDiv.append(inpTextBox);
    inpTextBox.focus();
    
    headersDiv.append("<br><br><label id='lblStatus' class='lblGeneral'>Status</label>");
    headersDiv.append("<label id='lblErrSts' class='lblGeneral'>-</label><br><br>");
    
    
    
    //Create Total type count label.
    var lblTypeCount = $(document.createElement("label"));
    lblTypeCount.attr("id", "lblTypeMsg");
    lblTypeCount.attr("for", "Message");
    lblTypeCount.addClass("lblGeneral");
    lblTypeCount.after().html("Total Type #:");
    headersDiv.append(lblTypeCount);
    lblTypeCount = $(document.createElement("label"));
    lblTypeCount.attr("id", "lblTypeCount");
    lblTypeCount.attr("for", "TypeCount");
    lblTypeCount.after().html(typeCounts);
    headersDiv.append(lblTypeCount);
    
    
    
    //Create types listbox.
    var slctTypesBox = $(document.createElement("select"));
    slctTypesBox.attr("id", "slctTypesBox");
    slctTypesBox.addClass("slctBox");
    slctTypesBox.attr("size", "8");
    contentDiv.append(slctTypesBox);
    var divHlpMessage = $(document.createElement("div"));
    divHlpMessage.attr("id", "divHlpMessage")
    divHlpMessage.addClass("helpMessage");
    divHlpMessage.after().html("<h4 id='h4HlpMessage'>Help Messages</h4><br><ul id='ulHelps' style='text-align: left'></ul>");
    $('#Footer').append(divHlpMessage);
    $('#Footer').append("<label class='lblGeneral'>Data: [(Subtype, [listOfSupertypes])]</label><br>");
    $('#Footer').append("<textarea style='width: 300px; height: 200px;' id='txtDagArea'></textarea>");
    
    
    //Create subTypeSelection
    var divSubContent = $('#subContent');
    var divSubTypeSel = $(document.createElement('div')).attr("id", "divSubType");
    divSubTypeSel.addClass("divSubtype");
    divSubContent.append(divSubTypeSel);
    var lblSubType    = $(document.createElement('label')).attr("id", "lblSubType");
    lblSubType.addClass('lblGeneral');
    lblSubType.after().html("<h3 id='h3LblSubType'>1</h3>");
    divSubTypeSel.append("<label id='lblSubTypeMsg' class='lblGeneral'><h3>SubType</h3></label>")
    lblSubType.appendTo(divSubTypeSel);
    
    var divSprTypesL = $(document.createElement('div')).attr("id", "divSprTypesL");
    divSprTypesL.addClass("divSprTypesL");
    divSubContent.append(divSprTypesL);
    $('#divSprTypesL').append("<select size=5 id='slctSprTypes' style='width: 300px; height: 300px;'></select>");
    
    
    //Starting add edit session on page load.
    addEditSession();
    $('subContent').addClass('invisible');
    
    //Keyboard UI Handle.
    //Textbox Enter pressed.
    $('#txtInpBox').keydown(function (event) {
        functionCaller[inpKeyCode.indexOf(event.keyCode)+1]();
    });
    
    //Check if all add conditions are satisfied.
    function addCondition() {
        var typeName  = $('#txtInpBox').val();
        var existCode = $('#slctTypesBox').find('option[value="'+typeName+'"]').length;
        errorMsgCaller[existCode] (typeName);
    }
    
    //Check the value is correct.
    function regexCheck(typeName) {
        var regexMatch = nullArray.indexOf(typeName.match("^[a-zA-Z]+[a-zA-Z0-9]*$"));
        var editOrAdd  = editingTypeArr.indexOf(editingType);
        addElementCall[regexMatch+1+editOrAdd](typeName);
    }
    
    //Incorrect Regex Error
    function incorrectValue() {
        addErrorClass($('#lblStatus'));
        $('#lblStatus').text("Error:");
        addErrorClass($('#lblErrSts'));
        $('#lblErrSts').text("Only Alphanumeric Strings Allowed.");
    }
    
    function showInfo(info) {
        addGeneralClass($("#lblStatus"));
        $("#lblStatus").text("Info:")
        addGeneralClass($("#lblErrSts"));
        $("#lblErrSts").text(info);
    }
    
    function showError(error) {
        addErrorClass($('#lblStatus'));
        $('#lblStatus').text("Error:");
        addErrorClass($('#lblErrSts'));
        $('#lblErrSts').text(error);
    }
    
    //Add an element.
    function addElement(typeName) {
        typeCounts++;
        $('#lblTypeCount').after().html(typeCounts);
        var newOption = $(document.createElement('option'));
        newOption.attr("value", typeName);
        newOption.attr("id", typeName);
        newOption.addClass("options");
        newOption.after().html(typeName);
        newOption.attr("selected", true);
        newOption.appendTo('#slctTypesBox');
        showInfo("Type added Succesfully.");
        createDag(typeName);
        return true;
    }
    
    function createDag(typeName) {
        createNode(typeName);
       /* $("#slctTypesBox option").each(function(i){
            createNode(this.val());
        });*/
    }
    
    function createNode(nodeVal) {
        //alert(nodeVal)
        var node = new Object();
        node.name = nodeVal;
        node.sprTypes = [];
        //alert(node.sprTypes);
        //alert(JSON.stringify(node));
        dag.types.push(node);
        //alert(JSON.stringify(dag));
    }
    
    function editOldType(typeName) {
        editingType = false;
        var editOption = $('#slctTypesBox option:selected');
        var editId = $('#slctTypesBox option:selected')[0].value;
        editDagEntry(editId, typeName);
        $('#'+editId).attr('value', typeName);
        $('#'+editId).after().html(typeName);
        $('#'+editId).attr("id", typeName);
        
        //alert($('#'+editId).value);
        
        showInfo("Type Edited Succesfully.");
        return true;
    }
    
    function editDagEntry(oldName, newTypeName) {
        for (var i=0; i<dag.types.length; i++) {
            var tempBool = (dag.types[i].name == oldName);
            i += dagEntryFun[editingTypeArr.indexOf(tempBool)](i, newTypeName);;
        }
    }
    
    function modifyDagEntry (i, newTypeName) {
        dag.types[i].name = newTypeName;
        return dag.types.length;
    }
    
    function deleteDagEntry (oldName) {
        for (var i=0; i<dag.types.length; i++) {
            var tempBool = (dag.types[i].name == oldName);
            i += dagEntryFun1[editingTypeArr.indexOf(tempBool)](i);;
        }
    }
    
    function deleteAtPos(i) {
        dag.types.splice(i,1);
        return dag.types.length;
    }
    
    
    //Ignore Key Stroke.
    function doNothing() {
        //This function does Nothing.
        return 0;
    }

    //Error: Value in type box exists.
    function errorExists() {
        showError("Type already exists in the type list.");
    }
    
    
    function addErrorClass(lbl) {
        lbl.removeClass("lblGeneral");
        lbl.addClass("errorClass");
    }
    
    function addGeneralClass(lbl) {
        lbl.removeClass("errorClass");
        lbl.addClass("lblGeneral");
    }
    
    $('#slctTypesBox').keydown(function (event) {
        var slctedOption = $(this).find('option:selected');
        slctFunctCaller[slctKeyCode.indexOf(event.keyCode) + 1](slctedOption[0]);
    });
    
    function deleteType() {
        var slctedTypes = slctTypesBox.find("option:selected");
        typeCounts -= slctedTypes.length;
        for(i = 0; i < slctedTypes.length; ++i) {
            deleteDagEntry(slctedTypes[i].value);
        }
        slctedTypes.remove();
        lblTypeCount.text(typeCounts);
        
        showInfo("Type(s) deleted successfully.");
    }
    
    function addType(typeStr) {
        inpTextBox.val(typeStr.value);
        inpTextBox.focus();
        addEditSession();
    }
    
    function editType(typeStr) {
        editingType = true;
        inpTextBox.val(typeStr.value);
        inpTextBox.focus();
        addEditSession();
    }
    
    function subtypeSelection() {
        var selectedType = $('#slctTypesBox option:selected')[0].value;
        $('#h3LblSubType').after().html(selectedType);
        $('#slctSprTypes').after().html();
        
        addRemainingSprs(selectedType);
        //$('#divSprTypesL').append("</select>");
        subtypeSession();
        toggleCreateSub("visible", "invisible");
        $('#slctSprTypes').focus();
//        alert(($('#divSprTypesL :input:checked')[0].value));
    }
    
    function toggleCreateSub(class1, class2) {
        $('#Content').removeClass(class1);
        $('#Content').addClass(class2);
        $('#subContent').removeClass(class2);
        $('#subContent').addClass(class1);
        
    }
    
  
    
    function addRemainingSprs(subType) {
        var allTypes = $('#slctTypesBox option');
        var sprTypes = findSprTypes(subType);
        for(i = 0; i<allTypes.length; ++i) {
            if(subType != (allTypes[i].value)) {    
                if(sprTypes.indexOf(allTypes[i].value) == -1) {
                    if(chkSubTypes(allTypes[i].value, subType)) {
                        var newOption = $(document.createElement('option'));
                        newOption.attr("value", "opt" + allTypes[i].value);
                        newOption.attr("id", "opt" + allTypes[i].value);
                        newOption.addClass("options");
                        newOption.after().html(allTypes[i].value);
                        newOption.attr("selected", true);
                        newOption.appendTo('#slctSprTypes');
                    }
                    
                }
            }
        }
    }
    
    function chkSubTypes(sprType, subType) {
        for(var i=0; i<dag.types.length; ++i) {
            if(dag.types[i].name == sprType) {
                if(dag.types[i].sprTypes.indexOf(subType) == -1) {
                    return true;
                }
                else
                    return false;
            }
        }
    }
    
    $('#slctSprTypes').keydown(function (event) {
        var slctId = $('#slctSprTypes option:selected')[0].value;
        slctSprFuncCaller[slctSprCode.indexOf(event.keyCode)+1]('#'+slctId);
    });
    
    function saveSubtypeDag() {
        for (var i=0; i<dag.types.length; i++) {
            var tempBool = (dag.types[i].name == $('#h3LblSubType').text());
            i += dagEntryFun2[editingTypeArr.indexOf(tempBool)](i);
        }
        addEditSession();
    }
    
    function updateDag(i) {
        var ElementsInDag = $('#slctSprTypes option[class="slctedClass"]');
        for(var j = 0; j < ElementsInDag.length; ++j) {
            dag.types[i].sprTypes.push(ElementsInDag[j].innerHTML);
        }
    }
    
    function discardSubtype() {
        $('#slctSprTypes').after().html("");
        toggleCreateSub("invisible", "visible");
        selectSession();
        slctTypesBox.focus();
    }
    
    function addRemoveClass(id) {
        var tempBool = $(id).attr("class") == "slctedClass";
        addRmvClsFunc[addRmvClsCode.indexOf(tempBool)](id);
    }
    
    function removeClass(id) {
        
        $(id).removeClass("slctedClass");
        $(id).addClass("options");
    }
    
    function addClass(id) {
        $(id).removeClass("options");
        $(id).addClass("slctedClass");
    }
    
    function findSprTypes(oldName) {
        for (var i=0; i<dag.types.length; i++) {
            if (dag.types[i].name == oldName) {
                return dag.types[i].sprTypes;
            }
        }
    }
    
    
    function focusTypes() {
        var typeName = inpTextBox.val();
        showInfo("");
        var existCode = $('#slctTypesBox').find('option[value="'+typeName+'"]').length;
        slctFocusSession[existCode](typeName);
        var vale = $('#lblErrSts').text()
        showInfo(vale + " Data saved and session Ended");
        slctTypesBox.focus();
        slctTypesBox.attr("multiple", true);
        selectSession();
    }
    
    function dataSaved() {
        //var vale = $('#lblErrSts').text()
        //showInfo(vale + " Data saved and session Ended");
    }
    
    function addEditSession() {
        showDag();
        $('#slctSprTypes').after().html("");
        toggleCreateSub("invisible", "visible");
        
        $('#slctTypesBox').removeAttr("multiple");
        $('#h4HlpMessage').after().html('Current Session: Add/Edit Type');
        $('#ulHelps').after().html('<li>Press [Enter] key to add a new type.</li>' +
                                   '<li>Press [UP] or [DOWN] to add new type and end the "Add new type" session and proceed to "Subtype selection session".</li>' 
                                  );
        inpTextBox.focus();
    }
    
    function selectSession() {
        $('#h4HlpMessage').after().html('Current Session: Type Selection');
        $('#ulHelps').after().html('<li>Press [UP] or [DOWN] key to move selection.</li>' +
                                   '<li>Press [INS] key to modify current selected type name.</li>' +
                                   '<li>Press [ENTER] key to add new type using current selected type name string.</li>' + 
                                   '<li>Press [DEL] key to delete current selected type.</li>' + 
                                   '<li>Press [RIGHT] key to start Subtype creation session.</li>'
                                  );
    }
    
    function subtypeSession() {
        $('#h4HlpMessage').after().html('Current Session: Subtype Creation');
        $('#ulHelps').after().html('<li>Press [UP] or [DOWN] to move selection.</li>' +
                                   '<li>Press [SPACEBAR] to toggle selection of currently highlighted type.</li>' +
                                   '<li>Press [ESC] to discard the changes and exit from current session to previous session.</li>' + 
                                   '<li>Press [LEFT] to save the changes and exit from current session to type add session.</li>'
                                  );
    }
    
    function showDag() {
        $('#txtDagArea').after().html("[");
        
        for(var i=0; i<dag.types.length; ++i) {
            $('#txtDagArea').append("(" + dag.types[i].name + ", [");
            for(var j=0; j<dag.types[i].sprTypes.length; ++j) {
                $('#txtDagArea').append(dag.types[i].sprTypes[j] + ", ");
            }
            $('#txtDagArea').append("]), ");
        }
        $('#txtDagArea').append("]");
    }
    
});
