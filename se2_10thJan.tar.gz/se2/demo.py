from multiprocessing import Process
import multiprocessing
import os

def shruti():
	print "gugle"
def ravi():
	print "ravi"
def Mprint():
	print "hello world"

if __name__ == '__main__':
	shruti  = multiprocessing.process(name = 'shruti',target=shruti)
	ravi  = multiprocessing.process(name = 'ravi',target = ravi)
	Mprint = multiprocessing.process(name = 'Mprint',target=Mprint)

ravi.start()
shruti.start()
Mprint.start()


	
