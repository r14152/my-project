
i =1
ravi = raw_input()
while i<100000:
	print i*2
	i=i+1 
