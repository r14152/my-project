#this function is used to convert generate the md5sum valueof the given file
import hashlib
import gzip
import tarfile
def hashFile(path,blocksize):
	hasher = hashlib.md5()
	data =tarfile.open(path,"rb")
	buf = data.read(blocksize)
	while(len(buf)>0):
		hasher.update(buf)
		buf = f.read(blocksize)
	f.close()
	return hasher.hexdigest()
