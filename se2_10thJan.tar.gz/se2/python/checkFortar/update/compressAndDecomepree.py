import zlib
import gzip
import os
import hashlib
import sqlite3
#create one database which store the md5sum code
#and the file name for storing that thing

#file which return the md5sum value of the given file
def hashKeyGen(fileName,size):
	hasher = hashlib.md5()
	data =tarfile.open(path,"rb")
	buf = data.read(blocksize)
	while(len(buf)>0):
		hasher.update(buf)
		buf = f.read(blocksize)
	f.close()
	return hasher.hexdigest()
	
#this function is going to return the key and create the 
#tar.gz
def compressFile(fileName):
	compressData = zlib.compress(fileName)
	f_out = gzip.open(fileName+'.gz',"wb")
	f_out.write(compressData)
	return hashKeyGen(fileName+'.gz')

#read the database and concat all string

def fileCompres(keyStamp):
	conn = sqlite3.connect('tempDb.db')
	cur = conn.cursor()
	cur.execute("select * from details");
	result = cur.fetchall()
	conn.close()
	data=""
	for row in result:
		for uniqueData in row:
			data +=uniqueData+" "
		data +=','
	uniQueCode = compressFile(data)	
