
import time
import os
def ravi():
	print "ravi singh"
