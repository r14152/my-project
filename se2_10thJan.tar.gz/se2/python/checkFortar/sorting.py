#s=['aaa.json.1','ddd.json.3','hasd.json.12','asjad.json.2']
#s=s.split(',')
#print s
import os
import sqlite3
#we take a global varibale which use to always remeber time stamp

conn = sqlite3.connect('test.db')
path=os.path.expanduser('~/sem6/se2/dataFile')
s=os.listdir(path)
a=[]
for i in s:
    i=i.split('.')
    i[len(i)-1]=int(i[len(i)-1])
    a.append(i)
priorityValue =0   
sorted_list = sorted(a, key=lambda x:x[2])
print a
print sorted_list
a=[]
for i in sorted_list:
     i[len(i)-1]=str(i[len(i)-1])
for i in sorted_list:
    a.append('.'.join(i))
print a
for i in a:
	lst =[]
	priority =int(i.split('.')[-1])
	print priority
	finalPath = path+'/'+i
	fileName = i
	k= os.stat(path+'/'+i).st_mtime
	lst.append(priority)
	lst.append(fileName)
	lst.append(finalPath)
	lst.append(k)
	print fileName
	#conn.execute('insert into tempDb values(?,?,?,?);',lst)
    #print k
#conn.commit()
