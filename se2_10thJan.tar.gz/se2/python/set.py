 #use this program to check that how can python work
from multiprocessing import Process
import os

def myFirst(keyStamp):
	print "ravi Singh"
	print "os.processid :",os.getpid()
	print keyStamp
def mySecond(keyStamp):
	print "golu Singh"
	print "second One :",os.getpid()
	print keyStamp
if __name__ == '__main__':
	jobs=[]
	p = Process(target=myFirst,args=(2344,))
	p.start()
	p.join()
	q = Process(target=mySecond,args=(111232,))
	q.start()
	q.join()


