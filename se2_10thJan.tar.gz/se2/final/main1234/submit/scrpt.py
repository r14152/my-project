
import os,time
import json
import subprocess
#import fileWatcher
#import fileCompress
#import fileValidate


#read the configuration json file
with open('configuration.json') as fp:
	conFig = json.load(fp)
fp.close()
#get the current path
curntPath = os.getcwd()
#check that FinalDirectory Exists or Not
dirPath = curntPath+'/'+conFig['finalDir']
if not os.path.exists(dirPath):
	os.mkdir(dirPath)
#start the first fileWatcher file
fileCheck = curntPath+'/'+conFig['fileWatcher']
print fileCheck
if os.path.isfile(fileCheck):
	proc = subprocess.Popen("python "+fileCheck,shell=True)
	time.sleep(5)
