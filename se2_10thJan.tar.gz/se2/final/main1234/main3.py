import sys,sqlite3
import os,re
import json

dbName='tempDb.db'
fName='demo2.json'
k= os.stat('./'+fName).st_mtime
print k
with open(fName) as fp:
    data = json.load(fp)
#print data

#print dbName
#sqlite3 demo2.db
conn = sqlite3.connect(dbName)
print "Opened database successfully";
cur=conn.cursor()
conn.execute('''drop table aaa;''')
conn.execute('''drop table details;''')
conn.execute(
'''create table aaa(timeDetails double,fileName nvarchar(20) primary key); '''
)
conn.execute(
'''
CREATE TABLE details
           (firstName nvarchar(30) NOT NULL,
            middleName nvarchar(30),
            lastName nvarchar(30) NOT NULL,
            age nvarchar(3),
            postalCode nvarchar(6) NOT NULL, 
            streetAddress nvarchar(30) NOT NULL,
            city nvarchar(30) NOT NULL,
            state nvarchar(30) NOT NULL,
            type1 nvarchar(30),
            phNo1 nvarchar(15),
            type2 nvarchar(30),
            phNo2 nvarchar(15),
            type3 nvarchar(30),
            phNo3 nvarchar(15)
            ,
            fileName nvarchar(20),
    FOREIGN KEY (fileName) REFERENCES aaa(fileName)
    );

''')

print "Table created successfully";
q=[k]
q.append(fName)
print q
cur.execute("insert into aaa values(?,?);",q)
for i in range(0,len(data['persons'])):
     q=[]
     q.append(data['persons'][i]['firstName'])
     if data['persons'][i].has_key('middleName') :
         q.append(data['persons'][i]['middleName'])
     else:
         q.append('')
     
     q.append(data['persons'][i]['lastName'])
     
     if data['persons'][i].has_key('age'):
         q.append(data['persons'][i]['age'])
     else:
         q.append('')
     
     for j in range(0,len(data['persons'][i]['phoneNumbers'])):
         q.append(data['persons'][i]['phoneNumbers'][j]['type'])
         q.append(data['persons'][i]['phoneNumbers'][j]['number'])
   
     q.append(data['persons'][i]['address']['streetAddress'])
     q.append(data['persons'][i]['address']['city'])
     q.append(data['persons'][i]['address']['state'])
     q.append(data['persons'][i]['address']['postalCode'])
     q.append(fName)
     cur.execute("insert into details values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",q);
print "data insert sucessfully"
q=[fName]
result=cur.execute("select * from details,aaa where details.fileName=aaa.fileName and aaa.fileName=='"+fName+"'")
result=cur.fetchall()
print result


''''
cur.execute("insert into aaa values(213234324.3224553,'file1.json.1');")
cur.execute("insert into aaa values(213234324.3224553,'file1.json.2');")
cur.execute("insert into details values('Sachin','Ishwar','Sendulkar','22','411008','A304, Golden apartments','nupe','hm','home','000-20003000','mobile','1112223334','mobile','1112223335','file1.json.1');")

cur.execute("insert into details values('sjdd','dwje','bbwulkar','24','401008','djhf456, Golden temp  apartments','An','rj','home','040-20008900','mobile','9112225334','mobile','5512266335','file1.json.1');")

cur.execute("insert into details values('Ishwar','Shrimal','Gugale','20','411005','A904, Golden apartments anad road','pune','hm','home','000-20003110','mobile','1117723334','mobile','1112223345','file1.json.2');")

cur.execute("select * from details,aaa where details.fileName=aaa.fileName and aaa.fileName=='file1.json.2';")
result=cur.fetchall()
print result

cur.execute("select * from details,aaa where details.fileName=aaa.fileName and aaa.fileName=='file1.json.1';")
result=cur.fetchall()
print result
'''
