import sys
import os
import subprocess,time
cwd = os.getcwd()
#print cwd

#a=subprocess.call("ls ",shell=True)
old=([])
temp=0
while 1:
    dirs = os.listdir( cwd )
    for i in dirs:
        k= os.stat(i).st_mtime
        if k>temp:
            temp=k
    print temp    
    time.sleep(10)
    
