public class hello {

    public static void main(String[] args) {
	System.out.println("hello!");
        /* Enter your code here. Print output to STDOUT. Your class should be named Solution. */
    }
}
