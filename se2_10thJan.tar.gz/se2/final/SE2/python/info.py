import json

with open('demo3.json') as fp:
...     data = json.load(fp)
print data['persons']
print data['persons'][0]['age']
