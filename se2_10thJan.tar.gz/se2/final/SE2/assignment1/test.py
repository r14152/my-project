import sys,subprocess

#os.subprocess("sqlite3 t1.db",true)
subprocess.call("sqlite3 t1.db ",shell=True)
subprocess.call(".q ",shell=True)
