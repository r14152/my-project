#s=['aaa.json.1','ddd.json.3','hasd.json.12','asjad.json.2']
#s=s.split(',')
#print s
import os,re
import sqlite3
import time
#we take a global varibale which use to always remeber time stamp

conn = sqlite3.connect('testDb.db')
cur=conn.cursor()
conn.execute('''drop table priorityTable;''')
conn.execute('''CREATE TABLE priorityTable(priority int not null,name nvarchar(20) not null,path nvarchar(50) not null, timeStamp double);''')
priorityValue =0  
while 1: 
	path=os.path.expanduser('~/SE2/python/shruti')
	s=os.listdir(path)
	a=[]
	maxValue=0
	for i in s:
                if not os.path.exists(path+'/'+i):
                        continue
		k = os.stat(path+'/'+i).st_mtime 
		if k>priorityValue: 
			i=i.split('.')
			ch=(i[len(i)-1])
                        if re.match("([0-9]*$)",ch):
				i[len(i)-1]=int(i[len(i)-1])
				a.append(i)
				print "ravi"
			if k>maxValue:
				maxValue = k
			#print "ravi",i,maxValue,priorityValue

	#print "resume ",priorityValue
	sorted_list = a	
	#sorted_list = sorted(a, key=lambda x:x[2])
	#print a
	#print sorted_list
	a=[]
	for i in sorted_list:
		i[len(i)-1]=str(i[len(i)-1])
	#for i in sorted_list:
		a.append('.'.join(i))
	print a
	for i in a:
		lst =[]
		priority =int(i.split('.')[-1])
		#print priority
		finalPath = path+'/'+i
		fileName = i
		k= os.stat(path+'/'+i).st_mtime
		lst.append(priority)
		lst.append(fileName)
		lst.append(finalPath)
		lst.append(k)
		conn.execute('insert into priorityTable values(?,?,?,?);',lst)
	conn.commit()
        if maxValue>priorityValue:
		priorityValue = maxValue
                
	time.sleep(5)
		#print fileName
    #print k
#conn.commit()
