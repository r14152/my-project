import sys,sqlite3
import os,re
import json

'''
f = open('input', 'r')
#for i in f:
f=f.readlines()
print f
li=[]
for i in f:
    li.append((i.split('\n'))[0])
print li
'''
with open('configuration.json') as fp1:
    data1 = json.load(fp1)
sleepTime=data1['sleepTime']
path=data1['path']
database=data1['database']
#print sleepTime,path,database

path=os.path.expanduser(path)
s=os.listdir(path)
a=[]
for i in s:
    i=i.split('.')
    i[len(i)-1]=int(i[len(i)-1])
    a.append(i)
   
sorted_list = sorted(a, key=lambda x:x[2])
#print a
#print sorted_list
a=[]
for i in sorted_list:
     i[len(i)-1]=str(i[len(i)-1])
for i in sorted_list:
    a.append('.'.join(i))
print a
for i in a:
    #print path+'/'+i
    k= os.stat(path+'/'+i).st_mtime
    print k



with open('demo2.json') as fp:
    data = json.load(fp)
#print data
#print data['persons'][0]['phoneNumbers']
#print a
#import sqlite3 as lite
#import sys
'''
db = r'someDb.sqlite'

def opendb(db):
    try:
        conn = lite.connect(db)
    except sqlite3.Error:
        print "Error open db.\n"
        return False
    cur = conn.cursor()
    return [conn, cur]
'''
dbName=database+'.db'
#print dbName
#sqlite3 demo2.db
conn = sqlite3.connect(dbName)
print "Opened database successfully";
cur=conn.cursor()
conn.execute(
'''CREATE TABLE details
       (firstName nvarchar(30) NOT NULL,
        middleName nvarchar(30),
        lastName nvarchar(30) NOT NULL,
        age nvarchar(3),
        postalCode nvarchar(6) NOT NULL, 
        streetAddress nvarchar(30) NOT NULL,
        city nvarchar(30) NOT NULL,
        state nvarchar(30) NOT NULL,
        type1 nvarchar(30),
        phNo1 nvarchar(15),
        type2 nvarchar(30),
        phNo2 nvarchar(15),
        type3 nvarchar(30),
        phNo3 nvarchar(15)
        );'''
)


#print len(data['persons'])
for i in range(0,len(data['persons'])):
     q=[]
     chk=data['persons'][i]['firstName']
     if not re.match("[A-Za-z]*$",chk):
            print "Invalid firstname "+chk
            continue   
     else:
            q.append(chk)
         

     
     if data['persons'][i].has_key('middleName') :
          chk=data['persons'][i]['middleName']
          if not re.match("[A-Za-z]*$",chk):
                  print "Invalid middlename "+chk
                  continue   
          else:
                  q.append(chk)
         
     else:
         q.append('')
     
     chk=data['persons'][i]['lastName']
     print chk
     if not re.match("[A-Za-z]*$",chk):
            print "Invalid lastName "+chk
            continue   
     else:
            q.append(chk)
     
     if data['persons'][i].has_key('age'):
         chk=data['persons'][i]['age']
         if(chk>0 and chk<150):
             q.append(chk)
             print "valid"
         else:
             print "invalid age"+str(chk)
             continue
        
     else:
         q.append('')
     print q
     chk=data['persons'][i]['address']['streetAddress']    
     '''if not re.match("[A-Za-z]*$",chk):
            print "Invalid streetAddress "+chk
            continue   
     else:'''
     q.append(chk)    
     
     chk=data['persons'][i]['address']['city']    
     if not re.match("[A-Za-z]*$",chk):
            print "Invalid streetAddress "+chk
            continue   
     else:
            q.append(chk)  
     
     
     chk=data['persons'][i]['address']['state']    
     if not re.match("[A-Za-z]*$",chk):
            print "Invalid streetAddress "+chk
            continue   
     else:
            q.append(chk)  
     
     chk=data['persons'][i]['address']['postalCode']
     
     if re.match("[0-9]{6}$",chk):
             q.append(chk) 
     else:
            print "Invalid streetAddress "+chk
            continue 
     
     #(data['persons'][i]['age'])
     #q.append(data['persons'][i]['age']
     flag=0
     if data['persons'][i].has_key('phoneNumbers'):
              for j in range(0,3):
                    chk=data['persons'][i]['phoneNumbers'][j]['type']    
                    if not re.match("[A-Za-z]*$",chk):
                           print "Invalid phoneNumber type "+chk
                           flag=1
                           break   
                    else:
                           q.append(chk)  
                    chk=data['persons'][i]['phoneNumbers'][j]['number'] 
                    if re.match("[0-9]{3}[-]+[0-9-]{8}$",chk) or re.match("[0-9-]{10}$",chk):
                           q.append(chk)   
                    else:
                           print "Invalid phonenNumber "+chk
                           flag=1
                           break
                           
              if flag==1:
                  continue
     else:

              for j in range(0,6):
                   q.append('')
    
            
     cur.execute("insert into details values(?,?,?,?,?,?,?,?,?,?,?,?,?,?)",q);
     #conn.commit()

print "Table created successfully";
#cur.execute("INSERT INTO details values('Sachin','Ishwar','Sendulkar','22','A304, Golden apartments','nupe','hm','411008')");
conn.commit()
cur.execute("select * from details");
result=cur.fetchall()
print result
conn.close()
