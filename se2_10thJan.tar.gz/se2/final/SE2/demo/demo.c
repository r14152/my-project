#include<stdio.h>
#include<stdlib.h>
int main(int argc, char **argv) {
        int i;
        void *start_pos, *finish_pos;
        void *res[10];
        start_pos = sbrk(0);
        for (i = 0; i < 10; i++) {
                res[i] = malloc(10);
        }
        finish_pos = sbrk(0);
        return 0;
}
