this repo contains most of the code I write during lectures and some related stuff.

I'd like you to try to read at least the following papers 

[reference material, papers and other stuff][0]

I'd like to you read these musings to get an idea of what, why and how is expected from you.

[musings - about the dept] [1]

[musings - on exams] [1]

[musings - on study] [1]


[musings - why learn fundamentals] [1]

[musings - good books and bad books] [1]

[0] http://tinyurl.com/pucsdJuly16

[1] https://goo.gl/hLDhoL
