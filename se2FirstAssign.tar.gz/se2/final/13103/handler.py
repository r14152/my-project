import subprocess,time
if __name__=='__main__':
    getSubmitProjectFileP = subprocess.Popen(['python','getSubmitProjectFile.py'])
    tarFileP = subprocess.Popen(['python','tarFileProcess.py'])
    readmeP = subprocess.Popen(['python','readmeProcess.py'])
    while True:
        if getSubmitProjectFileP.poll() != None:
            getSubmitProjectFileP = subprocess.Popen(['python','getSubmitProjectFile.py'])
        if tarFileP.poll() != None:
            tarFileP = subprocess.Popen(['python','tarFileProcess.py'])
        if readmeP.poll() != None:
            readmeP = subprocess.Popen(['python','readmeProcess.py'])
    
