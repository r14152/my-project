import psycopg2,sys

#def connectToDb():
conn = None
try:
        conn = psycopg2.connect(database = 'pp_spc_se1',user='postgres',password='Farman')
        cur = conn.cursor()
except psycopg2.DatabaseError, e:
        print 'Error %s' %e
        sys.exit(1)

#if __name__=='__main__':
#       connectToDb()
