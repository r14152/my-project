
import os
import fileWatcher
import json


#read the configuration json file
with open('configuration.json') as fp:
	conFig = json.loads(fp)
fp.close()
#get the current path
curntPath = os.getcwd()
#check that FinalDirectory Exists or Not
dirPath = curntPath+'/'+conFig['finalDir']
if not os.path.exists(dirPath):
	os.mkdirs(dirPath)
#start the first fileWatcher file
fileCheck = curntPath+'/'+conFig['fileWatcher']
if os.path.isfile(fileCheck):
	os.system("fileCheck")
