import sys
import time

li=[1,2,3,4,5]
while(1):
    print li
    time.sleep(3)
