 0
down vote
	

#I don't know if people have ever tried to md5sum a gzipped file, but its certainly not deterministic. I modified @Omnifaurious answer to handle this situation:

def hashfile(path, hasher=None, blocksize=65536):
    """
    A function to hash files.

    See: http://stackoverflow.com/questions/3431825
    """
    import hashlib
    import gzip

    if hasher is None: hasher = hashlib.md5()

    try:
        f = gzip.open(path, "rb")
        buf = f.read(blocksize)
    except OSError:
        f = open(path, "rb")
        buf = f.read(blocksize)

    while len(buf) > 0:
        hasher.update(buf)
        buf = f.read(blocksize)

    f.close()
    return hasher.hexdigest()


