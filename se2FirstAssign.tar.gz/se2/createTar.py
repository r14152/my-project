import tarfile
import os

# path = path of the given file which u want to compress
tar = tarfile.open(tarfileName)
tar.add("")
tar.close()
