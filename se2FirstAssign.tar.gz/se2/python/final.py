#this one is final scrpyt which call every function
import os
import sys
import sqlite3
import time
#import validation
#import compressAndDecompress 
from multiprocessing import Process

def writeFile():
		print "ravi"
		time.sleep(5)
		print "singh"
def readFile():
		print "golu"
		time.sleep(17)
		print "kumar"

for i in range(0,4):
		proc = Process(target=writeFile)
		proc2 = Process(target=readFile)
		proc.start()
		proc2.start()
		proc2.join()
		proc.join()

print "End all process"
