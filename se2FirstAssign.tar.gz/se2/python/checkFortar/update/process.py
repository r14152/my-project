#this program is use for the demostration of working of the function

