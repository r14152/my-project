import os
import time

#use for get the current working directory path
path = os.getcwd()   
lst = os.listdir(path)
print len(lst)
