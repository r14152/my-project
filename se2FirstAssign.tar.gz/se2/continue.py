

strng ="ravi singh"
p = 20
while p>0:
	print p 
	p=p-1
l = raw_input()
